namespace Ambev.DeveloperEvaluation.Domain.Enums
{
    public enum SaleStatus
    {
        Active = 1,
        Cancelled = 2
    }
}
